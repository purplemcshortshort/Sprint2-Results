package com.example.timeswipe;

public class ListTask {
	private String name;
	private String date;
	
	public ListTask(){
		
	}
	
	public ListTask(String n, String d){
		name = n;
		date = d;
	}
	
	public void setName(String n){
		name = n;
	}
	
	public void setDate(String d){
		date = d;
	}
	
	public String getName(){
		return name;
	}
	
	public String getDate(){
		return date;
	}
}
