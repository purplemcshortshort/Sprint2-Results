/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Patricia Kelly D. Co
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2014-11-24
 * Initial code.
 * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2015-02-09
 * Changed the initial splash screen to an animated splash screen.
 */
/**
 * Created on 2014-11-24
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * Splash screen for the application.
 */

package com.example.timeswipe;

import android.app.AlertDialog;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import android.view.ViewGroup.LayoutParams;

public class ListUI extends Fragment {
	
	TableLayout listTable;
	Button addButton, deleteButton;
	EditText inputTask;
	//View v;
	
	Context context;
	
    public ListUI(Context c) {
        this.context = c;
    }
    
    View view;
    
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setHasOptionsMenu(true);
//    }
    
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.activity_list_ui, container, false);
//		context = this;
		listTable = (TableLayout) view.findViewById(R.id.listTable);
        addButton = (Button) view.findViewById(R.id.addButton);
        setAddButtonOnClickListeners();
        
        setHasOptionsMenu(true);
        return view;
	}
	
	private void setAddButtonOnClickListeners(){
		addButton.setOnClickListener(new Button.OnClickListener(){
			@Override
        	public void onClick(View v) {
//        		AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        		AlertDialog.Builder builder1 = new AlertDialog.Builder(v.getContext());
//        		inputTask = new EditText(context);
        		inputTask = new EditText(v.getContext());
        		builder1.setMessage("New task:");
        		builder1.setView(inputTask);
        		
        		builder1.setCancelable(true);
        		builder1.setPositiveButton("Okay",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        			}
        		});
        		
        		builder1.setNegativeButton("Cancel",
        				new DialogInterface.OnClickListener() {
        			public void onClick(DialogInterface dialog, int id) {
        				dialog.cancel();
        			}
        		});
        		
        		final AlertDialog alert = builder1.create();
        		alert.show(); 
        		
        		alert.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener()
        	      {            
        	          @Override
        	          public void onClick(View v)
        	          {
        	              boolean wantToCloseDialog = false;
        	              /* Do stuff, possibly set wantToCloseDialog to true then... */
//        	              addButton = (Button) v.findViewById(R.id.addButton);
        					setAddButtonOnClickListeners();
        					String task = inputTask.getText().toString();
        					
        					if (!task.equals("")){
        						addRow(task);
        						wantToCloseDialog = true;
        					}
        					else
        						Toast.makeText(getActivity().getApplicationContext(), "Please enter task", Toast.LENGTH_SHORT).show();
           	              if(wantToCloseDialog)
        	                  alert.dismiss();
        	          }
        	      });
        	}
       	});
    }
	
	private void addRow(String t){
//        TextView task = new TextView(context);
        TextView task = new TextView(this.getActivity().getApplicationContext());
        //design code    
        task.setText(t);
        task.setTextSize(50);

//        TableRow row = new TableRow(context);
        TableRow row = new TableRow(this.getActivity().getApplicationContext());
		
        row.addView(task);
 
        listTable.addView(row, new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        listTable.setStretchAllColumns(true);       
	}
	
//	private void fillTable(){
//		ArrayList<Task> tasks = List.get();
//        int lenList = tasks.size();
//        
//        Task t;
//        String currDate, prevDate;
//        TableRow row, rowDate;
//        TextView task, date;
// 
//        t = tasks.get(0);
//        currDate = t.getDate();
//        
//        rowDate = new TableRow(this);
//        row = new TableRow(this);
//        
//        date = new TextView(this);
//        task = new TextView(this);
//        
//        date.setText(currDate);
//        task.setText(t.getName());
//        
//       /* task.setTypeface(null, 1);
//        date.setTypeface(null, 1);*/
//
//      	task.setTextSize(22);
//      	date.setTextSize(22);
//      	
//      	task.setPadding(50,0,0,0);
//      	
//      	rowDate.addView(date);
//      	row.addView(task);
//
//    	listTable.addView(rowDate, new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
//    	listTable.addView(row, new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
//        for (int current = 1; current < lenList; current++) {
//        	prevDate = currDate;
//        	
//        	t = tasks.get(current);
//        	currDate = t.getDate();
//        	
//        	if(ListController.compareDate(prevDate,currDate) == 0){
//        		row = new TableRow(this);
//                task = new TextView(this);
//                task.setText(t.getName());
//                
//                task.setTextSize(22);
//              	task.setPadding(50,0,0,0);
//                row.addView(task);
//        	}
//        	else{
//        		row = new TableRow(this);
//        		rowDate = new TableRow(this);
//                task = new TextView(this);
//                date = new TextView(this);
//                task.setText(t.getName());
//                date.setText(currDate);
//                
//                task.setTextSize(22);
//              	date.setTextSize(22);
//              	
//              	task.setPadding(50,0,0,0);
//              	
//                row.addView(task);
//                rowDate.addView(date);
//
//            	listTable.addView(rowDate, new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
//        	}
//        	listTable.addView(row, new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
//        	
//        	/*
//        	row = new TableRow(this);
//            task = new TextView(this);
//            date = new TextView(this);
//            
////            //insert design code
// 
//        	
//            task.setText(tasks.get(current).getName());
//            date.setText(tasks.get(current).getDate());
// 
//            task.setTypeface(null, 1);
//            date.setTypeface(null, 1);
// 
//            task.setTextSize(20);
//            date.setTextSize(20);
//            
//            row.addView(task);
//            row.addView(date);
//            listTable.addView(row, new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
//            listTable.setStretchAllColumns(true);*/
//        }
//	}
	
//	@Override
//	public boolean onCreateOptionsMenu(Menu menu) {
//		// Inflate the menu; this adds items to the action bar if it is present.
//		getMenuInflater().inflate(R.menu.list_ui, menu);
//		return true;
//	}
	
//	@Override
//	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
//	    super.onCreateOptionsMenu(menu, inflater);
//	    inflater.inflate(R.menu.list_ui, menu);
//	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
