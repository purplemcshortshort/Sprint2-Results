/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2014-11-20
 * Initial code.
 * @version 1.1
 * @author Mary Jane T. Rubio
 * @since 2015-02-10
 * Added attribute Context
 * Removed the parameter Context from methods read() and write(PieSchedule)
 * @version 1.2
 * @author Mary Jane T. Rubio
 * @since 2015-02-27
 * Modified read and write methods.
 */
/**
 * Created on 2014-11-20
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * Data Access Object for the PieSchedule.
 */

package com.example.timeswipe;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.annotation.SuppressLint;
import android.content.Context;
/**
 * Reads and saves the PieSchedule from and to PieSchedule.txt.
 *
 */
public class PieScheduleDao {
     public static Context context;
     
     /**
      * read
      *  - Reads saved data about the PieSchedule
      * @since 2015-02-10
      * @param void
      * @return The resulting PieSchedule containing the data
      * @exception IOException
      * @exception FileNotFoundException
      */
     public static PieSchedule read(){
          PieSchedule ps = new PieSchedule();
          try{
               FileInputStream fis = context.openFileInput("PieScheduleSource.txt");
               InputStreamReader isr = new InputStreamReader(fis);
               BufferedReader br = new BufferedReader(isr);
               try{ 
            	    String line;
            	    /* Gets boolean isRunning from 1st line */
            	    line = br.readLine();
            	    if(line != null){
	            	     if(line.equals("true"))
	            	          ps.setRunning(true);
	            	     else
	            	    	  ps.setRunning(false);
            	    }
            	    	
                    /* Gets the start time, end time and remaining time from the 2nd line of the file.*/                
            	    line = br.readLine();
            	    if(line != null){
	                     /* Parse to start, end and remaining times. */
	                     String[] times = line.split(",");
	                     ps.setStartTime( new Time(times[0]));
	                     ps.setEndTime( new Time(times[1]));
	                     ps.setRemTime( new Time(times[2]));
            	    }
            	    while((line = br.readLine()) != null){
            	    	String[] data = line.split(",");
            	    	Slice s = new Slice(Float.parseFloat(data[0]),Float.parseFloat(data[1]),Integer.parseInt(data[2]),new Time(data[3]), new Task(data[4]));
            	    	ps.addSlice(s);
            	    }
               }catch(IOException e){
                    e.printStackTrace();
               }
          }catch(FileNotFoundException e){
               e.printStackTrace();
          }
          return ps;
     }
     
     /**
      * write
      *  - Saves PieSchedule's start time, end time, remaining time and the slices/tasks. 
      * @since 2015-02-10
      * @param ps The PieSchedule to be saved (PieSchedule)
      * @return true if writing succeeds, false otherwise
      * @exception IOException
      * @exception FileNotFoundException
      */
    @SuppressLint("WorldReadableFiles")
	public static boolean write(PieSchedule ps){
          try {
            @SuppressWarnings("deprecation")
			FileOutputStream fou = context.openFileOutput("PieScheduleSource.txt", Context.MODE_WORLD_READABLE);
               OutputStreamWriter osw = new OutputStreamWriter(fou);
               try{
            	    /* Writes boolean isRunning into the 1st line of the file*/
           	        osw.write(Boolean.toString(ps.isRunning())+"\n");
                    /* Writes the start time, end time and remaining time of the schedule into the 2nd line of the file*/
            	    osw.write(ps.getStartTime().toString()+","+ps.getEndTime().toString()+","+ps.getRemTime().toString()+"\n");
            	    /* Succeeding lines are data about the slices. One Slice per line.*/
            	    for(int i = 0; i < ps.getSize(); i++){
            	        Slice s = ps.getSlice(i);
            	    	osw.write(Float.toString(s.getStartAngle())+","+Float.toString(s.getSweepAngle())+","+Integer.toString(s.getColor())+","+s.getRemTime().toString()+","+s.getTask().getName()+"\n");   
            	    }
                    osw.flush();
                    osw.close();
                    return true;
               }catch(IOException e){
                    e.printStackTrace();
                    return false;
               }
          }catch(FileNotFoundException e){
               e.printStackTrace();
               return false;
          }
     }
}